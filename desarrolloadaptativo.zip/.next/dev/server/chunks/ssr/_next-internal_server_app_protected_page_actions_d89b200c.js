module.exports = [
"[project]/.next-internal/server/app/protected/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_protected_page_actions_d89b200c.js.map