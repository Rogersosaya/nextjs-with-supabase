module.exports = [
"[project]/.next-internal/server/app/auth/sign-up-success/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_auth_sign-up-success_page_actions_e41d2466.js.map