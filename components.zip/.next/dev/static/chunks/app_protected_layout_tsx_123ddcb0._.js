(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@supabase_storage-js_dist_module_434fd12f._.js",
  "static/chunks/node_modules_@supabase_auth-js_dist_module_e6c70351._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_3a6a7370._.js",
  "static/chunks/_a1c3afce._.js"
],
    source: "dynamic"
});
