module.exports = [
"[project]/.next-internal/server/app/auth/sign-up/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_auth_sign-up_page_actions_c446eac4.js.map